/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author PUTRI
 */
public class operasi extends UnicastRemoteObject implements  fungsi{
    double hasil;
    public operasi() throws RemoteException{
        
    }

    @Override
    public double tambah(double a, double b) throws RemoteException {
      hasil = a + b;
      return hasil;
    }

    @Override
    public double kurang(double a, double b) throws RemoteException {
      hasil = a - b;
      return hasil;
    }

    @Override
    public double kali(double a, double b) throws RemoteException {
     hasil = a * b;
     return hasil;
    }

    @Override
    public double bagi(double a, double b) throws RemoteException {
     hasil = a / b;
     return hasil;
    }
    
}
