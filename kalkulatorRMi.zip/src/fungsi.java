/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.rmi.*;
/**
 *
 * @author PUTRI
 */
public interface fungsi extends Remote {
    public double tambah(double a, double b) throws RemoteException;
    public double kurang(double a, double b) throws RemoteException;
    public double kali(double a, double b) throws RemoteException;
    public double bagi(double a, double b) throws RemoteException;
    
    
}
